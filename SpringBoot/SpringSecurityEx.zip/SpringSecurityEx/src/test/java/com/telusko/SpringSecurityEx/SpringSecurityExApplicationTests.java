package com.telusko.SpringSecurityEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityExApplicationTests {

	@Test
	void contextLoads() {
	}

}
