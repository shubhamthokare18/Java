package com.example.Person_8_7_2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Person872025Application {

	public static void main(String[] args) {
		SpringApplication.run(Person872025Application.class, args);
	}

}
