package com.example.Person_8_7_2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Person872025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
