package com.example.JavaCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
