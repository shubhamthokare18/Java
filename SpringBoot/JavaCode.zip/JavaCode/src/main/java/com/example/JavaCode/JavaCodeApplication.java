package com.example.JavaCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaCodeApplication.class, args);
	}

}
