package com.example.mailtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailtaskApplication.class, args);
	}

}
