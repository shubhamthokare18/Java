package com.example.mailtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailtaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
