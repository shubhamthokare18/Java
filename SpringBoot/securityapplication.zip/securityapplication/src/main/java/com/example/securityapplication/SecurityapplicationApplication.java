package com.example.securityapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityapplicationApplication.class, args);
	}

}
