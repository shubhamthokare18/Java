package com.example.hibernatevalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernatevalidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernatevalidationApplication.class, args);
	}

}
