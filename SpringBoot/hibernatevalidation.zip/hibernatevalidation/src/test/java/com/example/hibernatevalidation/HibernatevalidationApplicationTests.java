package com.example.hibernatevalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernatevalidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
