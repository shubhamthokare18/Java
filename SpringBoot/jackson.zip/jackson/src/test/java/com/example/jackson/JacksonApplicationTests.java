package com.example.jackson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JacksonApplicationTests {

	@Test
	void contextLoads() {
	}

}
