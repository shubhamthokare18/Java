package com.example.Aug6_SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aug6SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aug6SpringBootApplication.class, args);
	}

}
