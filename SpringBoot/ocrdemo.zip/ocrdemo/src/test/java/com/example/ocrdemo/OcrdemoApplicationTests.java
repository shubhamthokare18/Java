package com.example.ocrdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcrdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
