package com.example.queryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryserviceApplication.class, args);
	}

}
