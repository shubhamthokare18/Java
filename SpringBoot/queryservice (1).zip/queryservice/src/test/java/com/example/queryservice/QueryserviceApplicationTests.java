package com.example.queryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
