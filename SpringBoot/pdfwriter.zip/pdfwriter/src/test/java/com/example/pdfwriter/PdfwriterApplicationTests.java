package com.example.pdfwriter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfwriterApplicationTests {

	@Test
	void contextLoads() {
	}

}
