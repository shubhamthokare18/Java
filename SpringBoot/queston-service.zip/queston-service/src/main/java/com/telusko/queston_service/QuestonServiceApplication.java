package com.telusko.queston_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestonServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestonServiceApplication.class, args);
	}

}
