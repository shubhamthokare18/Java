package com.telusko.queston_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
