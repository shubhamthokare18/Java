package com.example.readmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadmailApplication.class, args);
	}

}
